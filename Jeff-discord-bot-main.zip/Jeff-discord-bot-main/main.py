import bot

if __name__ == '__main__':
    # run bot
    bot.run_discord_bot()