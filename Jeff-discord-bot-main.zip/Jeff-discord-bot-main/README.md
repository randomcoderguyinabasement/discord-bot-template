This is for updates with the discord bot Jeff to copy over to my Raspberry Pi to host the bot.
